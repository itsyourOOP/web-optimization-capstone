// some variables that are referenced by but not included in libperf.a
// never care the values, as they are not used!
int use_browser = -1;
const char perf_version_string[] = "";
